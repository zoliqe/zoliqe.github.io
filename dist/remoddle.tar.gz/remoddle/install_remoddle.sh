#cd
#cd remoddler
#dart pub get
#cd bin
#echo "Compiling remoddler..."
#dart compile exe remoddler.dart

# echo "Compiling audio..."
# ./gcc_audio.sh

# echo "Compiling paddle..."
# ./gcc_paddle.sh

#echo "Installing rc.local..."
#sudo cp rc.local /etc/
#sudo chmod +x /etc/rc.local
#sudo chown root:root /etc/rc.local

cp Remoddle.desktop ~/Desktop/
mkdir ~/.config/autostart
ln -s ~/Desktop/Remoddle.desktop ~/.config/autostart/

cp start.sh ~/start.sh
chmod +x ~/start.sh
cp stop.sh ~/stop.sh
chmod +x ~/stop.sh
echo "$HOME/start.sh" >~/.profile

# cp remoddle.sh ~/remoddle.sh
# chmod +x ~/remoddle.sh
# cp remoddle.exe ~/remoddle.exe
# chmod +x ~/remoddle.exe
# cp paddle.py ~/paddle.py
# chmod +x ~/paddle.py
# cp lcd.sh ~/lcd.sh
# chmod +x ~/lcd.sh
# cp lcd_print.sh ~/lcd_print.sh
# chmod +x ~/lcd_print.sh
# cp remoddle.yaml ~/remoddle.yaml
# cp latest ~/latest
# cp -r bundle/* ~/
# chmod +x ~/rigller
# ln -s ~/rigller ~/rigller.exe
